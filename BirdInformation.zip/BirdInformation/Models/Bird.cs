namespace BirdInformation.Models
{
    public class Bird
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ScientificName { get; set; }
        public string Habitat { get; set; }
        public string Diet { get; set; }
    }
}
