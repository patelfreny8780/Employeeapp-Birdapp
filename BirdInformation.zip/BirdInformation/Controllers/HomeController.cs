using Microsoft.AspNetCore.Mvc;
using BirdInformation.Models;

namespace BirdInformation.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var birds = new List<Bird>
            {
                new Bird { Id = 1, Name = "Peacock", ScientificName = "Pavo cristatus", Habitat = "Forests", Diet = "Seeds and insects" },
                new Bird { Id = 2, Name = "Parrot", ScientificName = "Psittaciformes", Habitat = "Tropical forests", Diet = "Fruits and seeds" },
                new Bird { Id = 3, Name = "Eagle", ScientificName = "Accipitridae", Habitat = "Mountains and forests", Diet = "Small animals" },
                new Bird { Id = 4, Name = "Sparrow", ScientificName = "Passer domesticus", Habitat = "Urban areas", Diet = "Seeds and grains" },
                new Bird { Id = 5, Name = "Penguin", ScientificName = "Spheniscidae", Habitat = "Polar regions", Diet = "Fish and krill" },
                new Bird { Id = 6, Name = "Owl", ScientificName = "Strigiformes", Habitat = "Forests", Diet = "Small mammals" },
                new Bird { Id = 7, Name = "Flamingo", ScientificName = "Phoenicopteridae", Habitat = "Wetlands", Diet = "Algae and small organisms" },
                new Bird { Id = 8, Name = "Kingfisher", ScientificName = "Alcedinidae", Habitat = "Rivers and lakes", Diet = "Fish and insects" },
                new Bird { Id = 9, Name = "Crow", ScientificName = "Corvus", Habitat = "Cities and forests", Diet = "Omnivorous" },
                new Bird { Id = 10, Name = "Swan", ScientificName = "Cygnus", Habitat = "Lakes and rivers", Diet = "Plants and insects" }
            };

            return View(birds);
        }
    }
}
