using Microsoft.AspNetCore.Mvc;
using EmployeeApp.Models;
using EmployeeApp.Extensions;

namespace EmployeeApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            Employee employee = new Employee
            {
                Id = 1,
                Name = "Rahul",
                Department = "IT",
                Salary = 50000
            };

            string details = employee.GetEmployeeDetails();

            ViewBag.EmployeeDetails = details;

            return View(employee);
        }
    }
}
