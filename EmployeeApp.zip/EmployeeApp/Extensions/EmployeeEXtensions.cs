using EmployeeApp.Models;

namespace EmployeeApp.Extensions
{
    public static class EmployeeExtensions
    {
        public static string GetEmployeeDetails(this Employee employee)
        {
            return $"{employee.Name} works in {employee.Department} department and earns ₹{employee.Salary}";
        }
    }
}
